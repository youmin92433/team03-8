const input = document.getElementById("input");
const trList = document.querySelectorAll("tbody tr");

let prevTr = null;
let prevText = null;

const send = () => {
    let value = input.value;
    console.log(value);
    if (value === "" || isNaN(Number(value))) {
        alert("나이를 올바르게 입력하세요");
        return;
    }

    const age = Number(value);

    if (prevTr) {
        prevTr.style.color = "black";
        prevTr.firstElementChild.textContent = prevText;
    }

    let target = null;

    if (age >= 0 && age <= 12) {
        target = trList[0];
    } else if (age >= 13 && age <= 18) {
        target = trList[1];
    } else if (age >= 19 && age <= 64) {
        target = trList[2];
    } else if (age >= 65) {
        target = trList[3];
    } else {
        alert("올바른 나이 범위가 아닙니다.");
        input.value = "";
        return;
    }

    prevTr = target;
    prevText = target.firstElementChild.textContent;

    target.style.color = "red";
    target.firstElementChild.textContent = "★" + prevText;
};
